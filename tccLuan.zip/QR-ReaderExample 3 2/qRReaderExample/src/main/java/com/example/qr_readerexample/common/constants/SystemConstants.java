package com.example.qr_readerexample.common.constants;

import android.graphics.Bitmap;

import java.io.ByteArrayOutputStream;

/**
 * Created by lmonte on 02/05/16.
 */
public class SystemConstants {


}